<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        // return view('');
        echo view('layout/header');
        echo view('welcome_message');
        echo view('layout/footer');
    }
}
