    <section class="hero-section">
        <!-- <div class="img-bg"><img src="assets/images/bg/banner-portal.jpg"></div> -->
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-xl-12">
                    <div class="hero-content">
                        <h2 class="title">PORTAL TRANSPARANSI ANGGARAN</h2>
                        <h2 class="title">PROVINSI SULAWESI UTARA</h2>
                        <p>Transparansi anggaran merupakan salah satu pilar penting dalam
                            tata kelola pemerintahan yang baik. Pemerintah Provinsi Sulawesi
                            Utara berkomitmen penuh untuk mengedepankan prinsip keterbukaan dalam
                            pengelolaan keuangan daerah.</p>
                        <a href="https://sulutprov.go.id" class="btn btn-danger" target="_blank">Beranda</a>
                        <!-- <a href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#tahun-2020">Tahun 2020</a>
                        <a href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#opd-modal">Tahun 2021</a> -->
                        <a href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#tahun-2023">Tahun 2023</a>
                        <a href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#tahun-2024">Tahun 2024</a>
                    </div>
                </div>
            </div>
        </div>
    </section>