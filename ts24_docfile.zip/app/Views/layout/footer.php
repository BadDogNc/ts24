<!-- Scripts -->
<script src="<?= base_url('assets/js/vendor/modernizr-3.11.2.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/vendor/jquery-3.6.0.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/vendor/jquery-migrate-3.3.2.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/vendor/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/plugins/swiper-bundle.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/ajax-contact.js'); ?>"></script>
<script src="<?= base_url('assets/js/plugins/ajax-mailchimp.js'); ?>"></script>
<script src="<?= base_url('assets/js/plugins/aos.js'); ?>"></script>
<script src="<?= base_url('assets/js/plugins/scroll-up.js'); ?>"></script>
<script src="<?= base_url('assets/js/plugins/waypoints.js'); ?>"></script>
<script src="<?= base_url('assets/js/plugins/jquery.selectric.min.js'); ?>"></script>
<script src="<?= base_url('assets/js/main.js'); ?>"></script>

</body>

</html>