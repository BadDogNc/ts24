<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TRANSPARANSI ANGGARAN | PROVINSI SULUT</title>
    <!-- Favicon -->
    <!-- <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('assets/images/fav/apple-cc.png'); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('assets/images/fav/cc-32x32.ico'); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('assets/images/fav/cc-16x16.png'); ?>" />
    <link rel="manifest" href="<?= base_url('assets/images/favicons/site.webmanifest'); ?>" /> -->

    <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url() ?>/assets/images/fav/apple-cc.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url()  ?>/assets/images/fav/cc-32x32.ico" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url() ?>/assets/images/fav/cc-16x16.png" />
    <link rel="manifest" href="<?= base_url('assets/images/favicons/site.webmanifest'); ?>" />

    <link rel="stylesheet" href="<?= base_url('assets/css/vendor/icofont.min.css'); ?>" />
    <link rel="stylesheet" href="<?= base_url('assets/css/plugins/animate.min.css'); ?>" />
    <link rel="stylesheet" href="<?= base_url('assets/css/plugins/swiper-bundle.min.css'); ?>" />
    <link rel="stylesheet" href="<?= base_url('assets/css/plugins/aos.css'); ?>" />
    <link rel="stylesheet" href="<?= base_url('assets/css/plugins/selectric.css'); ?>" />
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>" />
</head>

<body>

    <!-- Tahun 2023 Modal -->
    <div class="modal offcanvas-modal fade" id="tahun-2023">
        <div class="modal-dialog offcanvas-dialog">
            <div class="modal-content">
                <div class="modal-header ">
                    <h6 style="color:#121212; margin-left:-16px; padding-top: 10px;">Transparansi anggaran tahun 2023</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- offcanvas-menu start -->
                <nav class="offcanvas-menu">
                    <ul>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/rencana-kerja-pemerintah-daerah-provinsi-sulawesi-utara-tahun-2023" style="border-top: 1px solid #000;" target="_blank">Informasi Ringkasan Dokumen RKPD</a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/kua-2023" target="_blank">Informasi Kebijakan Umum Anggaran</a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/rka-skpd-2023" target="_blank">Informasi Ringkasan Dokumen RKA SKPD</a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/perda-apbd-2023" target="_blank">Informasi Peraturan Daerah tentang APBD</a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/penjabaran-apbd-2023" target="_blank">Informasi Peraturan Kepala Daerah tentang Penjabaran APBD</a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/dpa-skpd-2023" target="_blank"> Informasi Ringkasan DPA SKPD </a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/realisasi-belanja-daerah-ta-2023" target="_blank"> Informasi Realisasi Belanja Daerah </a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/perda-perkada-perubahan-apbd-2023" target="_blank"> Informasi Peraturan Kepala Daerah tentang Penjabaran Perubahan APBD </a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/realisasi-belanja-daerah-ta-2023" target="_blank"> Informasi Laporan Realisasi Anggaran Seluruh SKPD </a>
                        </li>
                    </ul>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/lra-2023" target="_blank"> Informasi Laporan Realisasi Anggaran PPKD </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/ppas-2023" target="_blank"> PPAS </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/pages/informasi-realisasi-penyerapan-penggunaan-keuangan-tahun-2023" target="_blank"> INFORMASI REALISASI / PENYERAPAN PENGGUNAAN KEUANGAN </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/pages/dipa-dan-rka-kl-2023" target="_blank"> INFORMASI DIPA dan RKA-KL </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/lpe-audited-2023" target="_blank"> Laporan Perubahan Ekuitas </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/laporan-arus-kas-2023" target="_blank"> Laporan Arus Kas </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/laporan-oprasional-2023" target="_blank"> Laporan Oprasional </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/laporan-neraca-2023" target="_blank"> Laporan Neraca </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/lp-saldo-2023" target="_blank"> LP Saldo </a>
                    </li>
                    <li>
                        <a href="https://sulutprov.go.id/detailpost/lra-audited-2023" target="_blank"> LRA AUDITED </a>
                    </li>
                </nav>
            </div>
        </div>
    </div>

    <!-- Tahun 2024 Modal -->
    <div class="modal offcanvas-modal fade" id="tahun-2024">
        <div class="modal-dialog offcanvas-dialog">
            <div class="modal-content">
                <div class="modal-header ">
                    <h6 style="color:#121212; margin-left:-16px; padding-top: 10px;">Transparansi anggaran tahun 2024</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- offcanvas-menu start -->
                <nav class="offcanvas-menu">
                    <ul>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/perda-apbd-2024" style="border-top: 1px solid #000;"> Informasi Peraturan Daerah tentang APBD </a>
                        </li>
                        <li>
                            <a href="https://sulutprov.go.id/detailpost/penjabaran-apbd-2024">Informasi Peraturan Kepala Daerah tentang Penjabaran APBD </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <header class="header">
        <div class="header-top bg-reds">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col col-lg-4 d-none d-lg-block">
                        <ul class="header-social-links d-flex flex-wrap align-items-center">
                            <li class="social-link-item"><a href="#" class="social-link"><i class="icofont-facebook"></i></a></li>
                            <li class="social-link-item"><a href="#" class="social-link"><i class="icofont-twitter"></i></a></li>
                            <li class="social-link-item"><a href="#" class="social-link"><i class="icofont-instagram"></i></a></li>
                            <li class="social-link-item"><a href="#" class="social-link"><i class="icofont-youtube"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4 d-none d-md-block">
                        <p class="d-flex flex-wrap align-items-center"><span class="hr-border d-none d-xl-block"></span>Informasi Realisasi Anggaran</p>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <ul class="select-box d-flex flex-wrap align-items-center justify-content-center justify-content-md-end">
                            <li class="select-item"><a href="https://diskominfo.sulutprov.go.id" target="_blank">Kontak: diskominfo.sulutprov.go.id</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>